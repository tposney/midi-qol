import { error, debugEnabled, i18n } from "../midi-qol.js";
import { log } from "../midi-qol.js";
import { configSettings } from "./settings.js";
let modules = { "about-time": "0.0",
	"betterrolls5e": "1.6.6",
	"dice-so-nice": "4.1.1",
	"itemacro": "1.0.0",
	"lmrtfy": "0.9",
	"lib-wrapper": "1.3.5",
	"dae": "0.9.05",
	"combat-utility-belt": "1.3.8",
	"times-up": "0.1.2",
	"conditional-visibility": "0.0",
	"monks-tokenbar": "1.0.55",
	"socketlib": "0.0",
	"advanced-macros": "1.0",
	"dnd5e-helpers": "3.0.0",
	"dfreds-convenient-effects": "2.1.0",
	"levels": "1.7.0",
	"levelsvolumetrictemplates": "0.0.0",
	"lib-changelogs": "0.0.0",
	"df-qol": "1.6.0",
	"ddb-game-log": "0.0.0"
};
export let installedModules = new Map();
export let setupModules = () => {
	for (let name of Object.keys(modules)) {
		const modVer = game.modules.get(name)?.data.version || "0.0.0";
		const neededVer = modules[name];
		const isValidVersion = isNewerVersion(modVer, neededVer) || !isNewerVersion(neededVer, modVer);
		installedModules.set(name, game.modules.get(name)?.active && isValidVersion);
		if (!installedModules.get(name)) {
			if (game.modules.get(name)?.active)
				error(`midi-qol requires ${name} to be of version ${modules[name]} or later, but it is version ${game.modules.get(name)?.data.version}`);
			else
				console.warn(`midi-qol | module ${name} not active - some features disabled`);
		}
	}
	if (debugEnabled > 0)
		for (let module of installedModules.keys())
			log(`module ${module} has valid version ${installedModules.get(module)}`);
};
export function dice3dEnabled() {
	//@ts-ignore
	// return installedModules.get("dice-so-nice") && game.dice3d?.isEnabled();
	return installedModules.get("dice-so-nice") && (game.dice3d?.config?.enabled || game.dice3d?.isEnabled());
}
export function checkModules() {
	if (game.user?.isGM && !installedModules.get("socketlib")) {
		//@ts-ignore expected one argument but got 2
		ui.notifications.error("midi-qol.NoSocketLib", { permanent: true, localize: true });
	}
	//@ts-ignore
	const midiVersion = game.modules.get("midi-qol").data.version;
	const notificationVersion = game.settings.get("midi-qol", "notificationVersion");
	if (game.user?.isGM &&
		!installedModules.get("lib-changelogs")
		&& !game.modules.get("module-credits")?.active
		//@ts-ignore
		&& isNewerVersion(midiVersion, notificationVersion)) {
		game.settings.set("midi-qol", "notificationVersion", midiVersion);
		//@ts-ignore expected one argument but got 2
		ui.notifications?.warn("midi-qol.NoChangelogs", { permanent: false, localize: true });
	}
	checkCubInstalled();
}
export function checkCubInstalled() {
	return;
	if (game.user?.isGM && configSettings.concentrationAutomation && !installedModules.get("combat-utility-belt")) {
		let d = new Dialog({
			// localize this text
			title: i18n("midi-qol.confirm"),
			content: i18n("midi-qol.NoCubInstalled"),
			buttons: {
				one: {
					icon: '<i class="fas fa-check"></i>',
					label: "OK",
					callback: () => {
						configSettings.concentrationAutomation = false;
					}
				}
			},
			default: "one"
		});
		d.render(true);
	}
}
Hooks.once('libChangelogsReady', function () {
	//@ts-ignore
	libChangelogs.register("midi-qol", `
0.9.26
* Added missing flags.midi-qol.optional.NAME.save.dex/wis etc to auto complete fields 
* Added "every" option to count fields, means you can use the effect every time it matches without it ever expiring.
* Fix for rolling tools with late targeting enabled.
* Concentration will be applied to the user of an item (even if all targets saved) if the item places a measured template and has non-instantaneous duration - wall of fire/thorns etc.
* Fix for the removal on any effect causing the removal of concentration.
* Overtime effects that roll damage no longer wait for the damage roll button to be pressed, instead they damage is auto rolled and fast forwarded.
* Support for GMs to apply effects (via the apply effects button) for other players. Effects are applied to whoever the GM has targeted.
* For macro writers: Additional workflow processing options to itemRoll(options)/completeItemRoll(item, options: {...., workflowOptions}).
You can set 
	lateTargeting: boolean to force enable/disable late targeting for the items workflow
	autoRollAttack: boolean force enable/disable auto rolling of the attack,
	autoFastAttack: boolean force enable/disable fast forwarding of the attack
	autoRollDamage: string (always, onHit, none)
	autoFastDamage: boolean force enable/disable fast Forward of the damage roll.
	Leaving these undefined means that the configured workflow options from the midi-qol configuration panel will apply.

0.9.25
* Fix for user XXX lacks permission to delete active effect on token introduced in 0.9.23 for concentration - same symptom different cause.

0.9.24
* Fix for user XXX lacks permission to delete active effect on token introduced in 0.9.23 for concentration

0.9.23
* Fix for double dice so nice dice rolling for damage bonus macro dice.
* Fix for late targeting causing concentration save to late target.
* A tweak to using monk's token bar for saving throws. Player rolls always are always visible to other players. If there are GM rolls and the player's are not allowed to see the rolls, the GM rolls will be split to a separate card and displayed only to the GM. This resolves the issue of NPC names being shown to players when doing saving throws with Monk's Token Bar.
* Fix for a maybe edge case where concentration removal was not working (concentration was removed but stayed on the actor).
* Tidy up so that late targeting does not apply when doing reactions, concentration saving throws or overtime effects.
* Late targeting window now appears next to the chat log so that you are well position to hit the damage button if required.
* Reactions now prompt for spell level when casting reaction spells and the reaction executes on the correct player client.
* Damage bonus macro damage is now added to base weapon damage by type before checking resistance/immunity (with a minimum of 0), so if you have 2 lots of piercing one that does 3 points and a bonus damage macro providing 5 the total damage of 8 will be applied (as it was before). If you have damage resistance to piercing the damage applied will be 4 points, instead of 3 points as it would have been when the damage resistance was calculated on each slashing damage and then added together. Should you wish to implement (who knows why) damage bonus macros that reduce damage, i.e. you do 1d4 less piercing damage because your're eyesight is bad, the damage bonus macro can return "-1d4[piercing]"


[Full Changelog](https://gitlab.com/tposney/midi-qol/-/blob/master/Changelog.md)`, "minor");
});
