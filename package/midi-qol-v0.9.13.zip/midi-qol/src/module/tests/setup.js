//import { setupBaseTests } from "./baseTests";
export function setupTests() {
	// setupBaseTests();
}
