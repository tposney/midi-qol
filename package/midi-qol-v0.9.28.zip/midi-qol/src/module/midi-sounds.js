export class MidiSounds {
	static getSound(playListName, soundName) {
		const playlist = game.playlists?.getName(playListName);
		//@ts-ignore
		return { playlist, sound: playlist?.sounds.getName(soundName) };
	}
	static async playSound(playListName, soundName) {
		const { playlist, sound } = this.getSound(playListName, soundName);
		//@ts-ignore
		if (playlist && sound) {
			//@ts-ignore
			playlist.stopAll();
			//@ts-ignore
			return playlist.playSound(sound);
		}
	}
	static async playRandomSound(playListName) {
		const playlist = game.playlists?.getName(playListName);
		if (playlist) {
			//@ts-ignore
			playlist.stopAll();
			//@ts-ignore
			const sounds = playlist.sounds;
			const soundIndex = Math.floor(Math.random() * sounds.contents.length);
			//@ts-ignore
			const sound = playlist.sounds.contents[soundIndex];
			//@ts-ignore
			playlist.playSound(sound);
		}
	}
	static getSubtype(item) {
		if (!item.type)
			return "";
		let subtype = "";
		switch (item.type) {
			case "weapon":
				subtype = "weapon:" + item.data.data.weaponType;
				break;
			case "equipment":
				subtype = "equipment:" + item.data.data.armor.type;
				break;
			case "consumable":
				subtype = "consumable:" + item.data.dataconsumableType;
				break;
			default: subtype = item.type + ":all";
		}
		return subtype;
	}
	static getSpecFor(type, subtype, selector) {
		let spec;
		/*
		spec = getProperty(getProperty(configSettings.midiSoundSettings, subtype) ?? {}, selector);
		if (!spec) spec = getProperty(getProperty(configSettings.midiSoundSettings, type) ?? {}, selector);
		if (!spec) spec = getProperty(getProperty(configSettings.midiSoundSettings, "all") ?? {}, selector);
		*/
		return spec;
	}
	static playSpec(spec) {
		if (spec.soundName !== "random")
			this.playSound(spec.playlistName, spec.soundName);
		else
			this.playRandomSound(spec.playlistName);
	}
	static processHook(workflow, selector) {
		if (!workflow.item)
			return;
		const subtype = this.getSubtype(workflow.item);
		let spec = this.getSpecFor(workflow.item.type, subtype, selector);
		if (!spec)
			return;
		this.playSpec(spec);
	}
	static midiSoundsReadyHooks() {
		Hooks.on("midi-qol.preItemRoll", async (workflow) => {
			this.processHook(workflow, "itemRoll");
		});
		Hooks.on("midi-qol.preAttackRoll", async (workflow) => {
			this.processHook(workflow, "attackRoll");
		});
		Hooks.on("midi-qol.AttackRollComplete", async (workflow) => {
			const subtype = this.getSubtype(workflow.item);
			let spec;
			if (workflow.isCritical) {
				return this.processHook(workflow, "critical");
			}
			else if (workflow.isFumble) {
				return this.processHook(workflow, "funble");
			}
			else if (workflow.hitTargets.size === 0) {
				return this.processHook(workflow, "miss");
			}
			else {
				return this.processHook(workflow, "hit");
			}
		});
		Hooks.on("midi-qol.preDamageRoll", async (workflow) => {
			return this.processHook(workflow, "damageRoll");
		});
	}
}
