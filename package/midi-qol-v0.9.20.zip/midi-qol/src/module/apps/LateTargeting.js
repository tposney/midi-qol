class LateTargetingDialog extends Application {
	//@ts-ignore .Actor, .Item
	constructor(actor, item, user, options = {}) {
		super(options);
		this.data.actor = actor;
		this.data.item = item;
		this.data.user = user;
	}
	async getData(options = {}) {
		let data = mergeObject(this.data, await super.getData(options));
		this.data = data;
		return data;
	}
}
export {};
