import { criticalDamage, itemDeleteCheck, nsaFlag, coloredBorders, checkBetterRolls } from "../settings.js";
import { configSettings } from "../settings.js";
import { warn, i18n, debug } from "../../midi-qol.js";
export class ConfigPanel extends FormApplication {
    static get defaultOptions() {
        return mergeObject(super.defaultOptions, {
            title: game.i18n.localize("midi-qol.ConfigTitle"),
            template: "modules/midi-qol/templates/config.html",
            width: 520,
            height: 845,
            closeOnSubmit: true,
        });
    }
    get title() {
        return i18n("midi-qol.ConfigTitle");
    }
    getData() {
        var _a;
        let data = {
            configSettings,
            speedItemRollsOptions: i18n("midi-qol.speedItemRollsOptions"),
            autoCheckHitOptions: i18n("midi-qol.autoCheckHitOptions"),
            clickOptions: i18n("midi-qol.clickOptions"),
            autoTargetOptions: i18n("midi-qol.autoTargetOptions"),
            autoCheckSavesOptions: i18n("midi-qol.autoCheckSavesOptions"),
            autoRollDamageOptions: i18n("midi-qol.autoRollDamageOptions"),
            criticalDamage,
            autoApplyDamageOptions: i18n("midi-qol.autoApplyDamageOptions"),
            damageImmunitiesOptions: i18n("midi-qol.damageImmunitiesOptions"),
            showItemDetailsOptions: i18n("midi-qol.showItemDetailsOptions"),
            itemDeleteCheck,
            hideRollDetailsOptions: i18n("midi-qol.hideRollDetailsOptions"),
            nsaFlag,
            coloredBorders,
            checkBetterRolls,
            playerRollSavesOptions: i18n("midi-qol.playerRollSavesOptions"),
            //@ts-ignore .map undefined
            customSoundsPlaylistOptions: game.playlists.entries.reduce((acc, e) => { acc[e._id] = e.name; return acc; }, {}),
            customSoundOptions: (_a = game.playlists.get(configSettings.customSoundsPlaylist)) === null || _a === void 0 ? void 0 : _a.sounds.reduce((acc, s) => { acc[s._id] = s.name; return acc; }, { "none": "" }),
            rollSoundOptions: CONFIG.sounds
        };
        warn("Returning data ", data);
        return data;
    }
    onReset() {
        this.render(true);
    }
    async _updateObject(event, formData) {
        debug("Form data is ", formData);
        const newSettings = mergeObject(configSettings, formData, { overwrite: true });
        console.warn("data is ", formData, configSettings);
        if (game.user.isGM)
            game.settings.set("midi-qol", "ConfigSettings", newSettings);
    }
}
